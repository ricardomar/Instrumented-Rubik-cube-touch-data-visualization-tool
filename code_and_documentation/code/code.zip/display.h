

#ifndef __INC_DISPLAY_H
#define __INC_DISPLAY_H


#include "_cube.h"


void rundisplay( CUBE *cube, int argc, char *argv[] );


#endif 
